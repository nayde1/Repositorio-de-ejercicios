const express = require('express');
const mongoose = require('mongoose');
const { ApolloServer, gql } = require('apollo-server-express');

const Persona = require('./models/persona');
const cors = require('cors');

mongoose.connect('mongodb+srv://andreaahuizteco:la2025289Alam@cluster0.njosvdi.mongodb.net/grapgql', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const typeDefs = gql`
   type Persona {
    id: ID!
    rut: Int!
    nombre: String!
   }
   type Alert {
    message: String
   }

   input PersonaInput {
    rut: Int!
    nombre: String!
   }
   type Query {
       getPersonas(page: Int, limit: Int = 1): [Persona]
       getPersonaById(id: ID!): Persona
       getPersonaByNombre(nombre: String!): Persona
   }
   type Mutation {
    addPersona(input: PersonaInput): Persona
    updPersona(id: ID!, input: PersonaInput): Persona
    delPersona(id: ID!): Alert
   }
`;

const resolvers = {
    Query: {
        async getPersonas(obj, { page, limit }) {
          const personas = await Persona.find();
          return personas;  
        },
        async getPersonaById(obj, { id }) {
            const persona = await Persona.findById(id);
            return persona;
        },
        async getPersonaByNombre(obj, { nombre }) {
            const persona = await Persona.findOne({ nombre });
            return persona;
        },
    },
    Mutation: {
        async addPersona(obj, { input }) {
            const persona = new Persona(input);
            await persona.save();
            return persona;
        },
        async updPersona(obj, { id, input }) {
            const persona = await Persona.findByIdAndUpdate(id, input, { new: true });
            return persona;
        },
        async delPersona(obj, { id }) {
            await Persona.deleteOne({ _id: id });
            return {
                message: `La persona ${id} fue eliminada`
            };
        }
    }
};

const corsOptions = {
    origin: "http://localhost:8090",
    credentials: false
};

async function startServer() {
    const apolloServer = new ApolloServer({ typeDefs, resolvers, cors: corsOptions });
    await apolloServer.start();
    apolloServer.applyMiddleware({ app });
}

const app = express();
app.use(cors());
startServer();

app.listen(8090, function(){
    console.log('Servidor Iniciado');  
});


//http://localhost:8090/graphql
//para ejecutar este servidor: node ./server.js